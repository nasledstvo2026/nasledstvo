---
name: "lena-news-expert"
description: "Дайджест новостей по наследству + РЖД 1Р-37R, дедупликация, классификация"
---

# Skill: lena-news-expert

## Описание
Специалист по мониторингу новостей и законодательства по наследству + облигации РЖД 1Р-37R. Для Лены (@lena, ID: 254785028).

## Файлы навыка
- `agents/shared/lena-raw.json` — отфильтрованные новости (пишет scripts/lena_collect.py)
- `agents/shared/lena-verified.json` — верифицированные новости (пишет lena-verify-agent)
- `agents/shared/lena-news-seen.md` — дедупликация (история URL, пишет scripts/lena_collect.py)
- `knowledge/lena/news-knowledge.md` — база знаний (шаблоны, категории, источники)
- `knowledge/lena/rzd-knowledge.md` — база знаний по облигациям РЖД
- `knowledge/lena/sources.json` — реестр источников (17 шт.)
- `knowledge/lena/raw-baseline.json` — пороги для healthcheck
- `scripts/lena_collect.py` — детерминированный сбор+фильтр (без LLM)
- `scripts/lena_healthcheck.py` — сверка raw с baseline

## Источники
1. **LegalMCP** (legalmcp.ru) — для законодательных изменений по наследству (ГК РФ, ФЗ о нотариате, НК РФ)
2. **web_search** — поиск новостей, законодательных проектов
3. **Домены для search-agent:** tass.ru, rbc.ru, kommersant.ru, vedomosti.ru, rg.ru, pravo.gov.ru, notariat.ru, banki.ru, duma.gov.ru, consultant.ru, garant.ru, nalog.gov.ru, sfr.gov.ru, mintrud.gov.ru
4. **MOEX ISS API** — данные по облигациям РЖД 1Р-37R (rzd-search-agent)
5. **rusbonds.ru / cbonds.ru** — справочные данные по бондам (fallback для search-agent)

## База знаний новостей (knowledge/lena/news-knowledge.md)
Что должна содержать:
1. Категории новостей: законы (ФЗ, ПП, проекты), судебная практика, банки, нотариат, СФР, налоги, недвижимость, СВО
2. Шаблоны для каждого типа новости: заголовок, суть, для граждан, источник, тэги
3. Список проверенных источников и их тэгов (rg.ru, pravo.gov.ru, notariat.ru, banki.ru, duma.gov.ru)
4. Ключевые темы-маяки: Цифровое наследство, ЕИС нотариата, жилищные сбережения, сальдо ЕНС
5. Дедупликация: алгоритм проверки по URL + заголовку + дате + источнику
6. Формат дайджеста: Главное (1-2 новости с разбором), Коротко (3-5 новостей сводкой)

## База знаний РЖД (knowledge/lena/rzd-knowledge.md)
Что должна содержать:
1. ISIN: RU000A10AZ45
2. Параметры выпуска: номинал, купон, даты, оферта, амортизация
3. Ключевые индикаторы: цена, доходность, спред к ОФЗ, дюрация
4. Формат итогов торгов: цена закрытия, средневзвешенная, изменение, доходность, объём, сделки
5. Нормальные диапазоны для этого выпуска
6. Источники данных: MOEX ISS API (get_board_stateboard), rusbonds.ru

## Расписание
- **Ежедневно 02:00 МСК** — сбор новостей (lena-search-agent, cron; python3 scripts/lena_collect.py)
- **Ежедневно 02:10 МСК** — верификация новостей (lena-verify-agent, cron)
- **Ежедневно 02:20 МСК** — HTML-отчёт + публикация (lena-html-agent, cron)
- **Пн 03:00 МСК** — healthcheck источников (lena-healthcheck, cron)
- **Будни 23:55 МСК** — итоги торгов РЖД 1Р-37R (rzd-search-agent, cron)

## Директива для cron-промптов
**Все cron-промпты (search, verify, html, healthcheck, rzd) ДОЛЖНЫ ссылаться на этот SKILL.md и knowledge/lena/news-knowledge.md как на authoritative source.**

## Принципы
1. Лена — консультант для граждан. Язык простой, понятный.
2. Каждая новость — с пометкой "для граждан" (что это значит для обычного человека)
3. Дедупликация ОБЯЗАТЕЛЬНА: перед добавлением проверять agents/shared/lena-news-seen.md
4. Если новость повторяется — не включать, обновить дату в agents/shared/lena-news-seen.md
5. Ссылки на источники обязательны
6. Отчёты публикуются через publish-report.sh → GitHub Pages
7. В дайджесте не более 7 новостей (1-2 Главное + 3-5 Коротко)
8. LegalMCP: для проверки законодательных изменений (verify-agent, importance==main + категория law)
9. Лимиты: search ≤15 новостей, verify ≤10, html ≤7 (2+5)

