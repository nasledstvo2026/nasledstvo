---
name: "llm-cost-report"
description: "Посчитать расходы на LLM за период в разрезе пользователей/агентов. Триггер: «биллинг за llm», «сколько стоят агенты», «расходы в разрезе пользователей»."
---

# llm-cost-report

Оценка стоимости LLM по локальным логам сессий. Это оценка, а не биллинг провайдера.

## Две команды

1. **Итог + разбивка по дням**: `openclaw gateway usage-cost --json --all-agents --days <N>`
   → `totals.totalCost`, `daily[]` (по дням), `cacheStatus`. По пользователям НЕ разбивает.

2. **Per-session (для разреза по людям)**: `openclaw gateway call sessions.usage --json --params '{"agentScope":"all","limit":1000}'`
   → массив `sessions[]`: у каждой `key`, `label`, `origin.nativeDirectUserId`, `agentId`, `chatType`, `creatorKey`, `usage.totalCost/input/output/cacheRead`. Плюс `totals`, `aggregates.byAgent/byCreator/byModel`.

## Цены моделей

`~/.openclaw/openclaw.json` → `models.providers.deepseek.models[].cost` (за 1M токенов): `input`, `output`, `cacheRead`, `cacheWrite`. Пример: `deepseek-v4-flash` in 0.14 / out 0.28 / cacheRead 0.028; `deepseek-v4-pro` in 1.74 / out 3.48 / cacheRead 0.145.

## Атрибуция на пользователя

- `chatType == "direct"` → человек. Надёжный источник — последний сегмент ключа `agent:<agent>:telegram:direct:<uid>`; поле `origin.nativeDirectUserId` бывает `null` (проверено: Алиса 5216111644), тогда брать uid из ключа.
- `label` вида `"Cron: <имя>` / `"Automation: ..."` → автоматизация.
- Ключ `agent:<id>:subagent:<uuid>` → субагент; родителя взять из `spawnedBy` (есть в `openclaw sessions list --json`).
- Ключ `agent:main:<uuid>` (без `telegram`/`cron`/`subagent`) + `creatorKey: ["unknown"]`, `scope: "instance"` → внутренние сессии main (субагенты/восстановленные). По факту это работа владельца main-агента, а не отдельный пользователь.

## Оговорки

- Это оценка по локальным логам, не счёт провайдера.
- `usage-cost` и `sessions.usage` могут разойтись на копейки: `cacheStatus.status == "refreshing"` → кэш недогружен, повторить позже.
- Часть сессий может не попасть в лимит — задать `limit` побольше и проверить, что сумма по сессиям ≈ `totals.totalCost`.

## Completion checks

- Назван итог за период и разрез по людям/агентам.
- Указано, что это оценка (не биллинг) и откуда цены.
- Отмечены неатрибутированные субагентские сессии, если их доля значительна.

