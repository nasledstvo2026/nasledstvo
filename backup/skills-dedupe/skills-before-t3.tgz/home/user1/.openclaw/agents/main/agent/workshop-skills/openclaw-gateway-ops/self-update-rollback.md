# Self-update: разбор отката `post-core-update-failed`

Читать при любом откате апдейта OpenClaw: версия в `package.json` не сменилась, в `~/.openclaw/logs/support/openclaw-update-failure-*.json` стоит `reason: post-core-update-failed`.

## 1. Триаж: симптом → причина

- `Gateway service policy refresh skipped: SERVICE_DEFINITION_UNKNOWN: [unsafe-permissions] … group/world-writable` → права каталога systemd (причина №1).
- `Complete Doctor lint inventory … update-inspection-deferred … agent scopes need …ms … with 0ms remaining` → бюджет инспекции (причина №2, проверена 31.10.2026 на двух прогонах).
- `OpenClaw state at …/openclaw.sqlite is undergoing offline maintenance` → конкуренция за БД на пост-стадии; сопутствующий симптом, доказанной причиной не является.
- `packageRollbackVerified: true`, `after.version = before.version`, сервис `healthy` → штатный откат, а не поломка установки.

## 2. Где доказательства

- `systemctl --user list-units 'openclaw-update*' --all` — scope handoff'а; `running` = апдейт идёт.
- `/tmp/openclaw-update-run-handoff-*/handoff.log` — стадии, снапшоты БД, причина отказа, финальный JSON.
- `~/.openclaw/logs/support/openclaw-update-failure-*.json` — `error`, `result.steps`, `recovery`.
- `~/.openclaw/logs/support/openclaw-update-lint-*.json` — `doctorLintFindings[]`: `checkId`, `errorCode`, `requirement`, `message`.
- Версия: `node -p "require('/home/user1/.npm-global/lib/node_modules/openclaw/package.json').version"`.

## 3. Причина №1 — unsafe-permissions

Симптом в handoff-логе: политика сервиса не обновилась, юнит остался прежним (`Gateway service definition left unchanged`).

Лечение без рекурсии:

```bash
chmod 755 ~/.config ~/.config/systemd ~/.config/systemd/user ~/.config/systemd/user/openclaw-gateway.service.d
chmod go-w ~/.config/systemd/user/openclaw-gateway.service ~/.config/systemd/user/openclaw-gateway.service.d/*
find ~/.config/systemd -maxdepth 3 ! -type l -perm /022   # пусто = чисто; симлинки 777 — норма
```

Признак, что блокер снят: следующий прогон пишет `Reconciled Gateway service definition: Unit.StartLimitBurst, Unit.StartLimitIntervalSec, Service.TimeoutStopSec, Service.KillMode`.

## 4. Причина №2 — бюджет doctor-инспекции

Константы в `dist/doctor-update-budget-*.mjs`:
- `PUBLISHED_VALIDATION_WORK_MS = 298000` (298 с)
- `INSPECTION_WINDOW_MS = 149000` (149 с — половина)
- `AGENT_INSPECTION_ALLOWANCE_MS = 2000` на агента
- `RUN_INSPECTION_ALLOWANCE_MS = 5000`

Правило допуска: `Date.now() + allowance <= inspectionDeadline`; для agent-scope `allowance = agentCount × 2000`. Иначе проверка откладывается с `errorCode=update-inspection-deferred`, `requirement=update-validation-budget`, severity `warning`.

Расчёт на этом хосте: 10 агентов в `agents.entries` → нужно 20 000 мс; к моменту `core/doctor/lint-inspection` в окне оставалось **0 мс** → defer → неполный инвентарь → гейт «Complete Doctor lint inventory» → откат.

Важно: гейт валит апдейт на deferral, хотя сам finding — warning и его fixHint советует `openclaw doctor --fix` уже после активации. Env/конфиг-ручек для окна нет (есть только `OPENCLAW_UPDATE_RUN_ID` и `OPENCLAW_UPDATE_POST_INSTALL_DOCTOR_RESULT_PATH`) — окно не увеличить, можно только уменьшить работу и ускорить активацию. Поэтому ретрай «как есть» даёт тот же откат.

## 5. План окна обновления

1. **Бэкап** в `~/.openclaw/backups/upgrade-<версия>-<ts>/`: `state/openclaw.sqlite` (+wal/shm), `openclaw.json`, юнит, `gateway.systemd.env`, версии, `ROLLBACK.md`.
2. **Сократить ростер на окно**: `agents.entries` 10 → 2–3 (бэкап конфига, вернуть после). Допуск падает с 20 с до 4–6 с, активация короче. State агентов не трогать, только записи конфига.
3. **Снять фоновую нагрузку**: кроны (asv morning/evening, barbershop, ночные lena), heartbeat; убедиться, что нет активных прогонов.
4. **Освободить RAM**: попросить владельца перезапустить шлюз перед окном (свежий RSS ~1 ГиБ); проверить `free -h` (available ≥ 1,5 ГиБ), `load < 0.5`, swap почти не используется.
5. **`/update`** запускает владелец. Не вмешиваться; следить scope и `handoff.log`. Ожидаемо 30–45 мин.
6. **Проверка**: версия = целевая; `health`/`readyz` 200; `update status --json` → `available:false`; агенты и кроны на месте; `check.py` → CLEAN; в логах нет `update-inspection-deferred`.
7. **Вернуть конфиг** из бэкапа, попросить владельца перезапустить шлюз, включить кроны, перепроверить health и агентов.

## 6. Если откат повторился

- Проверить 2026.10.9 (`latest`) — в линии 10.x бюджет могли переработать.
- Поднять RAM VM (было 3,8 ГиБ при пике 3,3 ГиБ).
- Остаться на текущей версии, если релиз — патч без security-составляющей.
- Завести issue: гейт падает на deferral, который его же fixHint называет штатным.

## 7. Ловушки

- `gateway update.run` возвращает `status: "skipped", reason: "managed-service-handoff-started"` — это нормальный handoff, не ошибка; ack отправляет сам инструмент, дублировать нельзя; шлюз не рестартовать.
- `openclaw update status --json` после отката подвисает — оборачивать в `timeout`.
- `openclaw --help` виснет (ждёт stdin) — не вызывать.
- Логи содержат управляющие символы: `grep` только с `-a`.
- Не удалять lock-файлы и не делать рекурсивный `chmod` — каталог `~/.config/systemd/user` приводить к 755 точечно.
- Фоновые прогоны обрываются очисткой exec — тесты и проверки гонять в foreground.
