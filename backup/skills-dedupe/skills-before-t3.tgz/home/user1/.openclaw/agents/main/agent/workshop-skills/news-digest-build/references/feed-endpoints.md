# Feed endpoints: проверено 16.11.2026

Проба: `curl -sL -m 12 -A 'Mozilla/5.0 ... Chrome/124' -w '%{http_code} %{size_download}'`.
Перепроверять перед добавлением в новый сборщик: 403/429 часто защита от ботов, а не смерть фида.

## Рабочие (200)

- HN Algolia JSON — `https://hn.algolia.com/api/v1/search_by_date?query=AI%20agent&tags=story&hitsPerPage=40`
- TechCrunch AI — `https://techcrunch.com/category/artificial-intelligence/feed/`; startups — `…/category/startups/feed/`
- OpenAI news — `https://openai.com/news/rss.xml` — ~850 КБ, ~1400 items: фильтр по дате обязателен
- Google AI blog — `https://blog.google/technology/ai/rss/`
- NVIDIA blog — `https://blogs.nvidia.com/feed/`
- AWS ML blog — `https://aws.amazon.com/blogs/machine-learning/feed/`
- Product Hunt — `https://www.producthunt.com/feed` (по узкому слову даёт 0 — нужен широкий отбор)
- Import AI — `https://importai.substack.com/feed`
- Latent Space — `https://www.latent.space/feed`
- Interconnects — `https://www.interconnects.ai/feed`
- Simon Willison — `https://simonwillison.net/atom/everything/`
- arXiv cs.MA — `https://export.arxiv.org/api/query?search_query=cat:cs.MA&sortBy=submittedDate&sortOrder=descending&max_results=25`
  (http:// → 301; только https)
- Reddit — `https://www.reddit.com/r/AI_Agents/top/.rss?t=day`; `/top.json` → 403
- vc.ru — `https://vc.ru/rss`
- Habr news — `https://habr.com/ru/rss/news/`
- CNews — `https://www.cnews.ru/inc/rss/news.xml`
- HN front page — `https://news.ycombinator.com/rss`

## Мёртвые / нестабильные

- Anthropic `/rss.xml` и `/news/rss.xml` — 404: фида нет, нужен html-парсер `/news`
- Microsoft `https://blogs.microsoft.com/ai/feed/` — 410
- VentureBeat AI feed — 429
- Crunchbase news — 403
- Stratechery — 403
- Rusbase `https://rusbase.com/feed/` — SSL certificate expired
- Frank Media `/rss` — 404; рабочий фид `/feed` (проверено 17.11.2026)
- Reddit JSON — 403/429; `.rss` с браузерным UA и `?t=day` отдавал 200 (16.11), при повторных запросах 429/404 (17.11) — считать нестабильным, не делать единственной опорой

## Заметки по парсингу

- OpenAI/Atom: даты в `published`/`updated`, ссылка в `<link href>`.
- RSS: `pubDate` в RFC-822 (`email.utils.parsedate_to_datetime`), HTML в `description` чистить regex'ом.
- HN Algolia: `created_at_i` — unix seconds; `url` может отсутствовать → ссылка на item.
- Дата не извлеклась — не отбрасывать запись, складывать в undated для ручного разбора.

## Проба 17.11.2026 (параллельно, 16 потоков, timeout 6 с)

### Рабочие (200, FEED)
- MIT Tech Review — `https://www.technologyreview.com/feed/`
- Wired — `https://www.wired.com/feed/rss`
- Ars Technica — `https://feeds.arstechnica.com/arstechnica/index`
- The Verge — `https://www.theverge.com/rss/index.xml`
- Sifted — `https://sifted.eu/feed`
- Axios — `https://api.axios.com/feed/`
- One Useful Thing — `https://www.oneusefulthing.org/feed`
- AI Snake Oil — `https://www.aisnakeoil.com/feed`
- Exponential View — `https://www.exponentialview.co/feed`
- Benedict Evans — `https://www.ben-evans.com/benedictevans?format=rss`
- Not Boring — `https://www.notboring.co/feed`
- Platformer — `https://www.platformer.news/feed`
- TLDR AI — `https://tldr.tech/api/rss/ai`
- arXiv econ.GN — `https://export.arxiv.org/api/query?search_query=cat:econ.GN+AND+all:agent&sortBy=submittedDate&sortOrder=descending&max_results=20`
- Sequoia — `https://www.sequoiacap.com/feed/`
- Greylock — `https://greylock.com/feed/`
- Salesforce blog — `https://www.salesforce.com/blog/feed/`
- Frank Media — `https://frankmedia.ru/feed`
- RB.ru — `https://rb.ru/feeds/news/`
- Vedomosti — `https://www.vedomosti.ru/rss/articles`
- Inc Russia — `https://incrussia.ru/feed/`
- Cossa — `https://www.cossa.ru/rss/`
- Banki.ru — `https://www.banki.ru/xml/news.rss`
- Microsoft AI — `https://news.microsoft.com/source/topics/ai/feed/` (одиночно 200, в параллельном прогоне 403)

### Блокируют / нет фида
a16z 404 (`/feed`, `/rss`), Bessemer bvp.com 404, Index Ventures 404, Lightspeed lsvp.com 403,
Techstars 404, There's An AI For That 403, BetaList 404, Indie Hackers SSL reset, AppSumo 404,
Futurepedia 404, LlamaIndex 404, Make 403, LinkedIn reset, Gartner 403, CB Insights 403, Deloitte 403,
PwC 403, Stanford HAI reset, Coinbase 403, Virtuals 404, Skyfire 403, Upwork 403, Fiverr 403,
Semafor 404, Ben's Bites 403, The Neuron 403, Oborot 403, Kommersant 403, TAdviser 404,
Tinkoff Journal SSL (истёк сертификат).
Отдельно: `t.me/s/<channel>` — `Errno 101 Network is unreachable`, сеть хоста не пускает; это не 403 и не лечится сменой UA.

### Ловушка
- 403 под параллельной нагрузкой ≠ мёртвый фид: Menlo Ventures, Battery, Madrona, Microsoft AI отдавали 200 при одиночной пробе и 403 в прогоне на 16 потоков. Перепроверять одиночно перед вычёркиванием.
- VentureBeat — 429 и при одиночной пробе.
- Google News RSS как поиск — `https://news.google.com/rss/search?q=…` таймаутит с этого хоста (curl `-m 8` → exit 28), `web_fetch` на нём же зависает (проверено 18.11.2026).
- **Bing RSS — рабочая замена `web_search`:** `https://www.bing.com/search?q=<urlencoded>&format=rss&count=5` отдаёт 200 и валидный RSS (18.11.2026). Разбирать как обычный фид: `item/title`, `link`, `description`. Годится для добора, когда поискового провайдера нет.
- DuckDuckGo для скрейпинга не годится: `html.duckduckgo.com/html/?q=…` и `lite.duckduckgo.com/lite/?q=…` отдают 202 (антибот-заглушка), не результаты.
- `web_fetch` на внешние сайты иногда висит или отдаёт 419 — пробы и сбор делать `curl -m`, а не `web_fetch`.
