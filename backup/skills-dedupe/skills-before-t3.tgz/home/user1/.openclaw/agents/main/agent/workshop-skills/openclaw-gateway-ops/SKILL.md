---
name: "openclaw-gateway-ops"
description: "Обслуживание gateway OpenClaw: self-update и разбор отката post-core-update-failed, Node.js через apt, чистый рестарт и RAM-лимит кучи, диагностика «бот молчит», восстановление пропавшего cron-джоба, создание автоматизации. Триггеры: «обнови gateway», «обнови Node», «бот молчит», «пропал cron-джоб», «создай cron-джоб»."
---

# openclaw-gateway-ops

Операции с gateway OpenClaw на хосте Лунтик (vm-f13581, systemd user unit `openclaw-gateway.service`).

## Ключевое правило (читать первым)

`openclaw update`, `openclaw update repair` и `openclaw doctor --fix` **нельзя запускать изнутри процесса gateway** — а мой `exec` работает именно там.

Граница: обновление OpenClaw и рестарт шлюза инициирует владелец (`/update` в чате; рестарт — командой, которую даёт runtime). Runtime-политика запрещает агенту запускать `openclaw update`, `npm install -g openclaw` и stop/restart сервиса через exec или detached jobs — включая `systemd-run`. Моя часть — бэкап, preflight и проверка после; сами команды обновления и рестарта выполняет владелец/runtime, не я.

- `openclaw update` → «Package updates cannot run from inside the gateway service process».
- `openclaw doctor --fix` → «Doctor could not enter maintenance … running inside the gateway process tree».

Штатный путь апдейта — handoff в отдельном transient scope (`gateway update.run` или команда владельца), а не мой `exec`. Рестарт шлюза в любом случае убивает текущий `exec` (SIGTERM) — это ожидаемо: ход и итог смотрим в следующем ходу по файлам из раздела «Где смотреть ход и итог».

## Self-update

1. **Бэкап** в `~/.openclaw/backups/upgrade-<версия>-<ts>/`: `state/openclaw.sqlite` (+`-wal`/`-shm`), `~/.openclaw/openclaw.json`, `~/.config/systemd/user/openclaw-gateway.service`, `~/.openclaw/gateway.systemd.env`, снимок `openclaw --version`/`node -v`.
2. **План отката** — `ROLLBACK.md` в каталоге бэкапа (выполняет владелец): `npm install -g openclaw@<старая-версия>`; восстановить БД и `openclaw.json` из бэкапа; перезапуск шлюза.
3. **Preflight**: `openclaw update status --json` (канал, `hasRegistryUpdate`, `serviceDefinition.drift`), `openclaw doctor` (read-only), `systemctl --user is-active openclaw-gateway.service`. Плюс права: `find ~/.config/systemd -maxdepth 3 ! -type l -perm /022` должно быть пусто — иначе апдейт свалится на post-core. Плюс ресурсы под бюджет пост-проверки: число агентов (`agents.entries`), `free -h`, пик прошлого прогона; при 10+ агентах на 3,8 ГиБ RAM апдейт с высокой вероятностью откатится (см. `self-update-rollback.md`).
4. **Обновление** — владелец шлёт `/update` (или запускает `gateway` action `update.run`, если инструмент доступен); runtime сам координирует рестарт и уведомления, шлюз на время handoff остаётся доступен. Свой ack не дублировать. Команды `openclaw update --yes` / `update repair` / `doctor --fix` через exec не запускать: политика запрещает, и внутри шлюза они всё равно падают.
5. **Проверка**: `openclaw --version` = целевая, gateway `active`, `update status --json` → `available: false`, в логе нет `status=pending`.

### Откат self-update: `post-core-update-failed`

Признаки: версия в `~/.npm-global/lib/node_modules/openclaw/package.json` не изменилась, MainPID шлюза сменился, в `~/.openclaw/logs/support/openclaw-update-failure-*.json` — `reason: post-core-update-failed` и `recovery.packageRollbackVerified: true`. Версия переключается только на активации, поэтому «старая версия + новый PID» = откат, а не установка; откат штатный, шлюз после него `healthy`.

Причина №1 — права: в handoff-логе `Gateway service policy refresh skipped: SERVICE_DEFINITION_UNKNOWN: [unsafe-permissions] …` (каталог `~/.config/systemd/user` group/world-writable). Точные `chmod` без рекурсии и признак снятия блокера (`Reconciled Gateway service definition: …`) — `self-update-rollback.md`, §3.

Причина №2 — бюджет doctor-инспекции (проверено 31.10.2026, два прогона): окно инспекции 149 с, допуск agent-scope = 2 с × число агентов. При 10 агентах нужно 20 000 мс; к моменту `core/doctor/lint-inspection` в окне оставалось 0 мс → `update-inspection-deferred` → «Complete Doctor lint inventory» → `post-core-update-failed`. Ретрай «как есть» бесполезен: сокращать ростер на окно и освобождать RAM. Разбор, доказательства и план окна — `self-update-rollback.md`.

Где смотреть ход и итог (сам шлюз не рестартовать):
- `systemctl --user list-units 'openclaw-update*' --all` — scope handoff'а; `running` = апдейт идёт
- `/tmp/openclaw-update-run-handoff-*/handoff.log` — стадии, снапшоты, причина отказа
- `~/.openclaw/logs/support/openclaw-update-failure-*.json` и `openclaw-update-lint-*.json` — отчёт и инвентарь doctor
- CLI-проверки оборачивать в `timeout`: после отката `openclaw update status --json` подвисал

Каналы: `extended-stable` = стабильный трек (рекомендуется для продакшена); `latest` — свежий релиз; `beta` — не трогать. Проверено: обновление может пройти ядро, но `doctor` падает с отложенной конвергенцией плагинов (`status=pending`, причина «Package convergence must wait…») — дожимается владельцем парой `update repair` + `doctor --fix` из независимого shell.

## Node.js runtime (apt, хост)

Обновление системного Node под gateway. Не путать с self-update OpenClaw (npm): здесь меняется пакет `nodejs` из NodeSource, gateway потом нужно перезапустить, чтобы он поднял новый бинар.

1. **Инвентарь**: `node -v`, `npm -v`, `dpkg-query -W -f='${Version}' nodejs`, строка репозитория в `/etc/apt/sources.list.d`, `engines` установленного OpenClaw:
   `node -p "require('/home/user1/.npm-global/lib/node_modules/openclaw/package.json').engines"`
   (проверено 31.10.2026: `>=24.16.0 <25 || >=26.1.0` — 25.x не поддерживается).
2. **Что в апстриме**: скриптом-файлом (не `-c`) разобрать `https://nodejs.org/dist/index.json` — последняя версия в каждой мажорной ветке, LTS-метка; плюс `apt-cache policy nodejs` → `Candidate`. Патч внутри текущей ветки = низкий риск; переход на новую LTS = смена репозитория (`node_26.x`) и полный ретест.
3. **Базовый прогон тестов**: `bash ~/.openclaw/workspace/monitoring/node-update/test-node.sh > /tmp/node-test-before.log 2>&1; echo EXIT=$?`. Скрипт проверяет engines-диапазон, crypto/zlib/fs/worker_threads/node:sqlite, fetch+TLS (nodejs.org и POST к API АСВ), npm + глобальный openclaw, `openclaw --version`, health 200, unit active, `check.py` → CLEAN и валидность `seen.json`. Эталон: PASS=15 FAIL=0 SKIP=1.
4. **Апгрейд**: `sudo -n DEBIAN_FRONTEND=noninteractive apt-get install --only-upgrade -y nodejs`, затем `node -v`, `dpkg -l nodejs | tail -2` (`ii`), `sudo -n dpkg --audit` (пусто), `ls -l /usr/bin/node /usr/bin/npm`.
5. **Повторный прогон тестов** → `/tmp/node-test-after.log`; сравнить PASS/FAIL с базовым, версия должна попасть в engines-диапазон.
6. **Рестарт — только владелец**. Запущенный gateway держит старый бинар в памяти (MainPID не меняется), поэтому после апгрейда попросить `/restart`; самому шлюз через exec не перезапускать. После рестарта проверить `openclaw --version`, health 200 и `systemctl --user show -p MainPID` (PID новый).

**Ловушки, проверенные на практике:**
- `openclaw --help` в этой среде виснет (ждёт stdin) — CLI проверять через `--version`, `--help` не вызывать.
- Во время распаковки пакета `npm` может на миг исчезнуть — проверять после `dpkg --audit`, а не в момент установки.
- Вывод `openclaw --version` содержит управляющие символы: `grep` по логам — только с `-a`, иначе «binary file matches» и пустой результат.
- Фоновые прогоны (`nohup … &`) обрываются очисткой дочерних процессов exec — тесты гонять в foreground в пределах бюджета вызова либо делить на короткие шаги.

## Чистый рестарт + RAM

- Gateway — главный потребитель RAM (~1.9 ГБ из 3.8 ГБ, VPS маленький). Чистый рестарт сбрасывает фрагментацию кучи (~200 МБ RSS).
- Лимит кучи задан drop-in'ом `~/.config/systemd/user/openclaw-gateway.service.d/override.conf`: `Environment="NODE_OPTIONS=--max-old-space-size=1280"`. При OOM/тормозах поднять до 1536; ужесточить до 1024. После правки: `systemctl --user daemon-reload`; рестарт инициирует владелец, не через exec.
- Диагностика: `free -h`, `ps aux --sort=-%mem | head`, суммарный node: `ps aux | awk '/[n]ode/ {s+=$6} END {print s/1024" MB"}'`, пик процесса: `grep -E 'VmRSS|VmHWM' /proc/<pid>/status`.

## Бот молчит, хотя gateway активен (диагностика)

Симптом: `systemctl --user is-active openclaw-gateway.service` → `active`, `openclaw status` → канал Telegram `ON/OK`, входящие принимаются — но ответы не уходят.

Смотреть `journalctl --user -u openclaw-gateway` на признаки:
- `sendMessage failed` / `sendChatAction failed` / `editMessageText failed (retrying)`
- `fetch fallback: primary connection path failed … (UND_ERR_CONNECT_TIMEOUT)`
- `memory pressure: level=warning reason=rss_threshold rss=… threshold=…`

Дискриминатор сеть↔процесс: с хоста прогнать `curl -sS -m 15 -o /dev/null -w "HTTP=%{http_code} t=%{time_total}s ip=%{remote_ip}" https://api.telegram.org` **несколько раз подряд** (5–10, с паузой в секунду). Один быстрый ответ НЕ доказывает стабильность сети — egress бывает нестабильным. Разбор:
- Все ответы быстрые (0.1–0.5 с) → сеть в порядке, проблема в процессе: memory pressure (RSS выше порога) тормозит event loop → исходящие запросы к Telegram таймаутят, а входящие идут. Лечится рестартом gateway по конвенции хоста: на Лунтике рестарт инициирует владелец (агент сервис не перезапускает); на Фениксе — `bash ~/phoenix/safe-restart.sh`, НЕ `systemctl restart`.
- Часть или все ответы таймаутят (15 с+, `ip=` пустой) → нестабильный egress до Telegram на стороне VPS (проверено на Фениксе за NAT 10.0.0.x: curl то 0.14 с, то 15 с таймаут). Рестарт gateway не поможет — проблема сети/хостера.

## SSH к соседнему хосту: PAM блокирует вход

Проверять до любой удалённой диагностики: без shell нельзя посмотреть ни юнит, ни журнал.

Симптом: ключ принимается — в выводе `ssh -v` есть `Authenticated to <host> using "publickey"`, — но сразу после этого sshd печатает
`You are required to change your password immediately (password expired). Password change required but no TTY available.`
и рвёт сессию.

Это не проблема ключа или passphrase. PAM проверяет срок пароля аккаунта и не пускает дальше. Проверено 18.11.2026 на Фениксе: ключ и passphrase рабочие, вход блокировался только истёкшим паролем `user1`.

Решения:
- Вход по паролю может быть выключен совсем: попытка даёт `Permission denied (publickey)`. Тогда «зайти паролем» — не вариант.
- `ssh -tt` сам по себе не помогает: TTY даёт приглашение сменить пароль, но нужен текущий пароль, которого у агента нет.
- Владелец выполняет в консоли провайдера (VNC/rescue): `sudo chage -d today <user>` — снять истечение; либо `sudo passwd <user>` — задать новый.
- После этого — одна проверка входа и сразу диагностика: `systemctl --user is-active openclaw-gateway`, `journalctl --user -u openclaw-gateway -n 25`, `free -m`, `df -h`.

Запреты:
- Не перебирать пароли и не пытаться менять их вслепую через `ssh -tt`: fail2ban на таких хостах банит IP на ~10 минут, и диагностика откладывается.
- Не печатать и не сохранять пароли в чате, логах и скиллах.

## Восстановление пропавшего cron-джоба

Живое хранилище cron — SQLite (`openclaw cron list/show/add`), а не файл `~/.openclaw/cron/jobs.json`. После миграций `jobs.json` может отсутствовать; остаются легаси-снапшоты `~/.openclaw/cron/jobs.json.bak` и `jobs.json.migrated`, где лежат ПОЛНЫЕ определения старых джобов: `name`, `schedule.expr` + `schedule.tz`, `delivery.to`, `payload.message` (полный промпт), `payload.model`, `sessionTarget`, `enabled`.

Если джоб пропал из `openclaw cron list`, но когда-то существовал:

1. Найти определение: загрузить `jobs.json.bak` (или `.migrated`) в python, отфильтровать по ключевому слову (имя/ISIN/домен/часть промпта), вывести `payload.message`, `schedule`, `delivery.to`, `payload.model`.
2. Проверить, что внешний источник жив: `curl -sS -m 20 '<url>' -o /tmp/x.json -w 'HTTP=%{http_code}'` → ожидать 200.
3. Пересоздать через `openclaw cron add --name "…" --cron "55 23 * * 1-5" --tz Europe/Moscow --exact --agent main --session isolated --model deepseek/deepseek-v4-flash --announce --channel telegram --to <chatId> --tools "web_fetch read exec" --message "$(cat /tmp/msg.txt)"`. Старую модель из бэкапа (`deepseek/deepseek-chat`) заменять на актуальную (`deepseek-v4-flash`).
4. Проверка: `openclaw cron list | grep <имя>` — джоб виден со статусом `idle`.

## Автоматизации через tool `automations`

Создание джоба из агентского хода — tool `automations` (`action:"add"`, `job:{…}`), не CLI:

```js
automations({ action:"add", agentId:"main", job:{
  name: "…", agentId:"main", enabled: true,
  schedule: { kind:"cron", expr:"30 8 * * *", tz:"Europe/Moscow" }, // expr — локальное время в tz, не UTC
  sessionTarget: "isolated",              // "current" = эта беседа, "isolated" = отдельная сессия
  payload: { kind:"agentTurn", message, timeoutSeconds:900, toolsAllow:["read","write","exec","web_fetch"] },
  delivery: { mode:"announce", channel:"telegram", to:"telegram:<chatId>", accountId:"default" },
  failureAlert: { after:2, channel:"telegram", to:"telegram:<chatId>", cooldownMs:3600000 }
}})
```

- `target` в корне `job` — ошибка `invalid cron.add params: unexpected property 'target'`. Куда доставлять, задают `sessionTarget` + `delivery`.
- Точную структуру быстрее всего взять через `action:"get"` по id из `list`, чем угадывать поля.
- Проверка: `action:"get"` → `enabled:true`, `nextRunAtMs` (UTC) соответствует ожидаемому локальному времени.
- Принудительный прогон: `action:"run", runMode:"force"` возвращает `enqueued:true` и `runId` — это ещё не выполнение. Запись в `action:"runs"` появляется только по завершении; пока `state.runningAtMs` задан, а `lastRunAt` = null, прогон идёт (сбор + редактура ≈2–3 мин при `timeoutSeconds:900`) — не считать зависанием и не перезапускать. Итог смотреть по `lastRunStatus:"ok"`, `lastDelivered:true`, `runs[0].durationMs`.

## Completion checks

- Версия = целевая, gateway `active`, `openclaw update status --json` → `available: false`; правка прав не нужна (`find ~/.config/systemd -maxdepth 3 ! -type l -perm /022` пусто), новых `openclaw-update-failure-*.json` нет, в логах нет `update-inspection-deferred`.
- Node: `node -v` = целевая и в пределах engines, тесты после апгрейда без FAIL, health 200 на новом MainPID.
- `NODE_OPTIONS=--max-old-space-size=…` виден в `/proc/<pid>/environ` после рестарта.
- В `handoff.log` есть финальная стадия без `status=pending`; после рестарта — health 200 и новый MainPID.
- Восстановленный cron-джоб виден в `openclaw cron list` (статус `idle`), `openclaw cron show <id> --json` отдаёт корректный payload.
- Созданный через `automations` джоб: `get` → `enabled:true`, `nextRunAtMs` корректен, `delivery.to` — нужный чат.
- Форсированный прогон подтверждён не по `enqueued:true`, а по `runs[0].status:"ok"` + `lastDelivered:true`; артефакты прогона (архив выпуска, `seen.json`) реально появились на диске.

