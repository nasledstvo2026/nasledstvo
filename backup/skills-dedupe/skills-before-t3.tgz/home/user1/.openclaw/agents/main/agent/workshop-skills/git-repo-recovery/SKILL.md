---
name: "git-repo-recovery"
description: "Восстановление файлов, случайно удалённых коммитом публикации в git-репозитории отчётов; отдельный restore-коммит, пуш и проверка. Триггер: «файлы пропали из репозитория», «восстанови удалённое коммитом»."
---

# git-repo-recovery

Возврат файлов, которые попали в коммит как удаления. Частый случай — коммит публикации отчёта, где скрипт стейджит лишнее (`git add -A`). Работать в корне репозитория; существующие файлы не переписывать.

## 1. Зафиксировать масштаб

```bash
git status --short
git log --oneline -6
git show --stat --oneline <bad_commit>
git diff --name-status <bad_commit>^ <bad_commit> | awk '$1=="D"{print $2}'
```

Список удалённых путей сохранить в `/tmp/restore_files.txt`. Убедиться, что `<good_commit>` (родитель или предыдущий коммит) содержит их: `git cat-file -t <good_commit>`.

## 2. Восстановить и сверить

```bash
xargs -a /tmp/restore_files.txt git checkout <good_commit> --
git status --short          # все пути должны быть 'A'
xargs -a /tmp/restore_files.txt git diff --stat <good_commit> --   # пусто = совпадает
```

`git checkout <commit> -- <paths>` уже стейджит файлы; `git add` не нужен. Посторонние untracked-файлы не трогать.

## 3. Отдельный коммит и пуш

```bash
git commit -m "Restore files deleted accidentally in <bad_commit>"
git push origin master
```

Не смешивать восстановление с обычной публикацией отчёта. Ветка — та, из которой деплоит репозиторий (в nasledstvo — `master`).

## 4. Проверка

```bash
git rev-parse HEAD origin/master     # одинаковые SHA
xargs -a /tmp/restore_files.txt git diff --stat <good_commit> --   # пусто
while read -r f; do [ -f "$f" ] || echo "MISSING: $f"; done < /tmp/restore_files.txt
```

## Профилактика

- После каждого коммита публикации смотреть `git show --stat HEAD`: только целевой отчёт и служебные файлы; массовые `D` — сигнал, что скрипт стейджит лишнее.
- В скрипте публикации staged-список должен ограничиваться целевыми путями, а не `git add -A`.

## Completion checks

- Все пути из списка существуют; `git diff` против `<good_commit>` пуст.
- HEAD и `origin/master` совпадают; push прошёл.
- В коммите только восстановленные файлы (без отчётов и untracked-мусора).

## Проверено

19.10.2026: коммит `4fed798` удалил 23 файла (`HEARTBEAT.md`, `TOOLS.md`, 21 `skills/*/SKILL.md`). Восстановлены из `95d6bb2` коммитом `4a3f25c`, запушено `3c8580a..4a3f25c`; `git diff` против `95d6bb2` пуст, HEAD = `origin/master`.
