---
name: "model-switch"
description: "Переключение модели и reasoning-уровня агентов и сессий OpenClaw, пин/снятие пина, временный режим с автootкатом. Триггеры: «какая модель сейчас», «переключи на pro/flash», «включи reasoning», «сделай на час и верни»."
---

# model-switch

Смена модели и reasoning-уровня у агентов и сессий OpenClaw на хосте Лунтик.

## Где лежит модель

- `~/.openclaw/openclaw.json` → `agents.defaults.model.primary` — дефолт для всех.
- `agents.entries.<id>.model` — per-agent override (перебивает дефолт).
- Пин активной сессии хранится в сессионном sqlite, НЕ в конфиге. Показывает `openclaw status` (строка «Session … is pinned to X»).

## Переключить активную сессию на конкретную модель

Через инструмент `sessions` (работает и в runtime без shell):

```
sessions({action:"patch", sessionKey:"agent:main:telegram:direct:<uid>", model:"deepseek/deepseek-v4-pro"})
```

CLI-эквивалент:

```
openclaw gateway call sessions.patch --json --params '{"key":"agent:main:telegram:direct:<uid>","model":"deepseek/deepseek-v4-pro"}'
```

- Меняется только пин этой сессии; `agents.entries.*.model` и дефолт не трогаются.
- «Сильнее» = `deepseek/deepseek-v4-pro`, «дешевле/быстрее» = `deepseek/deepseek-v4-flash`. Модель должна быть в `agents.defaults.modelPolicy.allow`, иначе сессия уйдёт на дефолт.
- Текущий ход доигрывает на старой модели; новая применяется со следующей реплики.
- Сброс пина = `model: null` (для CLI), ожидать `"ok": true`.
- Ответ `sessions.patch` содержит блок `resolved` с фактической моделью — это и есть проверка, отдельный `openclaw status` не обязателен.

## Reasoning (thinking level)

Уровни, подтверждённые ответом `sessions.patch` (20.11.2026): `off`, `minimal`, `low`, `medium`, `high`, `xhigh`, `max`, `ultra`.

```
sessions({action:"patch", sessionKey:"agent:<id>:telegram:direct:<uid>", thinkingLevel:"high"})
```

- Уровень задаётся **на сессию**, а не в конфиге агента. Патч `thinkingLevel` не меняет модель и наоборот.
- Ответ: `updated:["thinkingLevel"]`, `resolved.model`, `resolved.thinkingLevel`, `resolved.thinkingLevels` — один вызов подтверждает оба факта.
- `high` — рабочий компромисс для сложных разборов; `xhigh/max/ultra` дороже и медленнее, включать только по явной просьбе.
- Reasoning раздувает выходные токены в разы: для рутины держать `off`, включать точечно.

## Временный режим с автootкатом («сделай на час»)

1. Правка конфига: `agents.entries.<id>.model` → целевая. Ветка `agents` применяется hot-reload без рестарта; `sessions_list` по `agentId` сразу показывает новую модель (проверено 20.11.2026).
2. `sessions.patch` → `thinkingLevel:"high"` на его активную сессию.
3. `automations add`: `schedule:{kind:"at", at:"<ISO UTC>"}`, `deleteAfterRun:true`, `agentId:"main"`, `payload:{kind:"agentTurn", message:"<точные шаги отката>"}`, `delivery:{mode:"announce", channel:"telegram", to:"<владелец>"}`.
   В сообщении jobs перечислить дословно: какой ключ модели вернуть, какие значения, `sessions.patch thinkingLevel:"off"`, проверка `sessions_list`, отчёт владельцу.
4. Время в `at` — **UTC**, не локальное. Пересчитать из Europe/Moscow (MSK = UTC+3), иначе откат сработает не тогда.
5. Проверка: `sessions_list({agentId})` → model; `automations get jobId` → `schedule.at`, `enabled`, `deleteAfterRun`.
6. Предупредить владельца: если шлюз перезапустится в момент срабатывания, откат может не выполниться — конфиг останется на временной модели, нужна ручная проверка.

Откат вручную: обратная правка `model` + `thinkingLevel:"off"` + `automations remove jobId` (если задача ещё жива).

**Если временный режим решили оставить навсегда** — задачу автootката удалить сразу (`automations remove`), иначе она молча вернёт старую модель в назначенный час. Проверка: ответ `removed:true` и отсутствие задачи в `automations list`.

**Задачу отката создавать только от своего агента:** `automations add` с чужим `agentId` падает с `job agentId outside caller scope`. Для другого агента — `agentId:"main"` (владелец), а в тексте задачи перечислить, чей ключ модели править; `delivery` — на чат владельца.

## Переключить всех на одну модель

1. Бэкап: `cp -a ~/.openclaw/openclaw.json ~/.openclaw/openclaw.json.bak-<метка>-<ts>`.
2. Список агентов с моделями (python json, см. ниже) → кто уже на целевой, кого переводить.
3. Точечная правка python json (НЕ sed по всему файлу — не портить другие секции): заменить `agents.entries.*.model`.
4. Валидность: `python3 -c "import json; json.load(open('/home/user1/.openclaw/openclaw.json')); print('JSON_VALID')"`.
5. **Снять пин с активных сессий** — правка конфига его НЕ трогает: закреплённая сессия продолжит на старой модели, пока пин не снят. Сброс = `model: null`:
   ```
   openclaw gateway call sessions.patch --json --params '{"key":"agent:main:telegram:direct:<uid>","model":null}'
   ```
   → ожидать `"ok": true`.

## Вспомогательные команды

Список агентов и их моделей:
```
python3 -c "import json; d=json.load(open('/home/user1/.openclaw/openclaw.json')); e=d['agents']['entries']; print({k:(e[k].get('model') or '?') for k in e})"
```

Текущая модель сессии / есть ли пин:
```
openclaw status 2>&1 | sed -n '/Model selection/,+6p'
```
Если `grep` по выводу `openclaw status` даёт пусто, смотреть секцию через `sed`: строки «Session … is pinned to …», «Configured default», «Session selected».

## Completion checks

- Целевая модель видна в `sessions_list` по `agentId` (значение без провайдер-префикса: `deepseek-v4-pro`) или в `resolved` ответа патча.
- Все `agents.entries.*.model` на целевой модели (проверено python json), JSON валиден.
- Для reasoning: `resolved.thinkingLevel` равен заданному; при откате — `off`.
- Временный режим: задача автootката существует, `schedule.at` в UTC соответствует заявленному сроку; после срабатывания — модель и уровень вернулись, задача удалена.
