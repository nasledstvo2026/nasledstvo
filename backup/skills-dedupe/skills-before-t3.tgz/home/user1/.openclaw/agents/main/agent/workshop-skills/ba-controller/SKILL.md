---
name: "ba-controller"
description: "Оркестратор BRD: сессия, интервью через Questioner, сборка, верификация, экспорт .docx. Триггер: «Создать БТ»."
---

# ba-controller — Оркестратор BRD

## Триггер
- Пользователь пишет «Создать БТ» в чате
- Сообщение маршрутизируется через AGENTS.md → sessions_send(agentId="ba-controller", message=full_user_message)

## Активация
- Получает полный текст сообщения пользователя
- Из входящего сообщения извлекает: sender_id, chat_id, message text

## Жизненный цикл сессии BRD

### Шаг 1: Создать сессию
- Сгенерировать UUID сессии
- Создать md_log:
```markdown
# BRD Session: <UUID>
## Meta
- user: <sender_id>
- chat: <chat_id>
- created: <timestamp>
- status: created
- iteration: 0
```

### Шаг 2: Запустить Questioner (через прокси Лунт)
- Questioner не имеет прямого доступа к Telegram-чату
- Протокол:
  1. sessions_send(agentId="ba-questioner", message=md_log) — отправить вопрос пользователю
  2. Questioner вернёт вопрос → Controller передаёт вопрос агенту main (Лунт) через reply
  3. Лунт пересылает вопрос пользователю в Telegram
  4. Пользователь отвечает → Лунт присылает ответ Controller-у → Controller передаёт Questioner-у
  5. Повторять шаги 2-4 пока Questioner не завершит интервью и не вернёт md_log с QuestionLog
- Таймаут простоя: 600 секунд без ответа пользователя (интервью рассчитано на 10–15 минут; глобальный лимит — 30 минут, см. таблицу)
- Если таймаут или глобальный лимит истёк → сохранить частичный QuestionLog
- Флаг завершения интервью: поле status=interview_complete в md_log

### Шаг 3: Запустить Compiler
- sessions_send(agentId="ba-compiler", message=md_log)
- Таймаут: 120 секунд
- Получить обратно md_log с CompiledBRD

### Шаг 4: Запустить Verifier
- sessions_send(agentId="ba-verifier", message=md_log)
- Таймаут: 90 секунд
- Получить обратно md_log с VerificationLog

### Шаг 5: Проверить вердикт Verifier
- Если Verdict=REVISION_NEEDED:
  - iteration++ (макс 2)
  - Вернуться к Шагу 3 с комментарием Verifier-а
- Если Verdict=APPROVED или iteration >= 2:
  - status = approved
  - Перейти к Шагу 6

### Шаг 6: Экспорт .docx
- Запустить скрипт: `python3 /home/user1/.openclaw/workspace/scripts/brd-to-docx.py`
- Вход: md_log
- Выход: `bt_<дата>_<UUID>.docx`

### Шаг 7: Отправка пользователю
- Отправить .docx в чат пользователя
- Добавить текст:
  ```
  ✅ БТ готов: bt_<дата>_<UUID>.docx
  Проблема: <корень>
  Цель: <SMART>
  Метрики: <KPI>
  ```

## Таймауты
| Агент | Max time | Fallback |
|-------|----------|----------|
| Questioner | 600 сек простоя | Сохранить частичные данные |
| Compiler | 120 сек | RCA без поиска |
| Verifier | 90 сек | APPROVED_FORCED без верификации |
| Глобальный | 30 мин | Abort, пользователю «начните заново» |

## Ошибки
- Questioner не ответил → уведомить пользователя «прервалось, попробуйте снова»
- Compiler не ответил → повторить 1 раз через 30 сек
- Verifier не ответил → пропустить верификацию, выдать с пометкой
- Ошибка .docx → выдать .md лог в чат текстом

## Прокси-протокол: обработка ответов пользователя
- Controller получает сообщение от Лунт (main-агент) с ответом пользователя
- Формат от Лунта:
  ```
  [USER_RESPONSE] <session_uuid>
  Ответ: <текст ответа пользователя>
  ```
- Controller извлекает session_uuid, находит активную сессию, передаёт ответ Questioner-у
- Questioner отвечает новым вопросом → Controller → Лунт → пользователь

## Биндинг
- Нет. Controller вызывается только через sessions_send.

## Доставка
- delivery.mode = none (ответы Controller не должны дублироваться в чат)
- Controller отвечает только через sessions_send обратно агенту-отправителю
